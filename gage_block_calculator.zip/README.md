# Gage Block Calculator

A simple CNC tool to find gage block combinations from 0.0500 to 1.0000 inches using Python and Flask.
